export const dashboardKitGalleryReport = {
  "generatedAt": "2026-08-08T21:55:50.550Z",
  "package": "@hermes/dashboard-kit",
  "purpose": "Visible component intake and approval status for package-native dashboard migrations.",
  "componentFamilies": 9,
  "namedComponents": 49,
  "statusSummary": {
    "approved": 9
  },
  "reviewSummary": {
    "averageScore": 100,
    "downstreamAdoptionScore": 52,
    "approved": 9,
    "reviewing": 0,
    "draft": 0,
    "needsRedesign": 0,
    "blockedProjects": 3,
    "unresolvedNextActions": 0,
    "familiesMissingClosureEvidence": [],
    "level5Ready": true
  },
  "requiredHumanReview": [],
  "references": [
    {
      "id": "market-intelligence",
      "label": "Market Intelligence",
      "references": [
        "Kraken",
        "Binance",
        "OKX",
        "Coinbase",
        "Mixpanel"
      ],
      "extraction": "Market browsing should combine category navigation, watchlist/tape scanning, axis-bearing charts, selected-market detail, liquidity/spread context, proof state, and insufficient-data states."
    },
    {
      "id": "media-operations",
      "label": "Media Operations",
      "references": [
        "Sprout Social",
        "Adobe Express",
        "Manus",
        "Replit",
        "PlanetScale"
      ],
      "extraction": "Content operations should separate command triage, approval queues, publishable channels, QA evidence, Discord handoff, posting status, and time-series output health."
    },
    {
      "id": "business-operations",
      "label": "Business Operations",
      "references": [
        "Asana",
        "Linear",
        "Wrike",
        "Productboard",
        "Plane"
      ],
      "extraction": "Business cockpits should show executive rollups, accountability, work queues, decision logs, objective progress, and evidence behind readiness."
    },
    {
      "id": "planning-calendar",
      "label": "Planning And Calendar",
      "references": [
        "Amie",
        "Motion",
        "Jobber",
        "Time2book",
        "Assembly"
      ],
      "extraction": "Planning views should use a real calendar/work surface, selected-day or range drawers, library-to-plan flows, manual override, and clear generated-versus-human state."
    },
    {
      "id": "cost-performance",
      "label": "Cost And Performance",
      "references": [
        "Vercel",
        "LangChain",
        "Mixpanel",
        "Employment Hero"
      ],
      "extraction": "Cost dashboards should pair spend timelines with provider attribution, business-unit impact, efficiency ratios, anomaly states, freshness, and drilldowns."
    },
    {
      "id": "proof-governance",
      "label": "Proof And Governance",
      "references": [
        "Linear",
        "PlanetScale",
        "Productboard",
        "Wrike"
      ],
      "extraction": "Governance surfaces should make ownership, proof, blockers, exceptions, adoption status, and next action visible without dumping raw audit text."
    }
  ],
  "reviewRegistry": {
    "version": 1,
    "updatedAt": "2026-08-07T00:00:00.000Z",
    "purpose": "Persistent review state for Hermes Dashboard Kit component families. This file is the auditable bridge between Mobbin/reference intake, human taste review, and project adoption."
  },
  "visualBaselines": {
    "version": 1,
    "route": "/dashboard-kit-gallery",
    "viewports": [
      {
        "id": "desktop",
        "width": 1440,
        "height": 1100
      },
      {
        "id": "tablet",
        "width": 1024,
        "height": 1000
      },
      {
        "id": "mobile",
        "width": 390,
        "height": 900
      }
    ],
    "themes": [
      "light",
      "dark"
    ],
    "requiredStates": [
      "default",
      "loading",
      "empty",
      "stale",
      "error",
      "overflow"
    ],
    "approvalRules": [
      "Every approved family must have desktop and mobile light-mode screenshots.",
      "Dark mode screenshots are required before a project can ship the family in dark mode.",
      "Primary charts must prove visible axes, labels, legends, units, and nonblank plotted regions.",
      "Tables must prove one card wrapper, one header, one toolbar, and one pagination footer.",
      "Shell captures must prove there is one shell and the content pane owns scrolling."
    ],
    "requiredCaptureCount": 45,
    "families": [
      {
        "id": "shell-navigation",
        "requiredCaptures": [
          "expanded sidebar",
          "collapsed sidebar",
          "mobile drawer",
          "proof strip"
        ]
      },
      {
        "id": "metric-proof",
        "requiredCaptures": [
          "metric strip",
          "proof strip",
          "freshness strip",
          "overflow stress"
        ]
      },
      {
        "id": "chart-suite",
        "requiredCaptures": [
          "line",
          "area",
          "bar",
          "donut",
          "heatmap",
          "loading",
          "empty",
          "stale",
          "error"
        ]
      },
      {
        "id": "tables-queues",
        "requiredCaptures": [
          "approval queue",
          "toolbar sorting",
          "pagination",
          "overflow stress"
        ]
      },
      {
        "id": "drawers-drilldowns",
        "requiredCaptures": [
          "right drawer",
          "market detail",
          "approval detail",
          "mobile bottom sheet"
        ]
      },
      {
        "id": "market-browser",
        "requiredCaptures": [
          "category browser",
          "sub-category rail",
          "market tape",
          "selected market",
          "stream proof"
        ]
      },
      {
        "id": "media-workflow",
        "requiredCaptures": [
          "package card",
          "approve/decline",
          "publishable channels",
          "posting proof",
          "Discord handoff"
        ]
      },
      {
        "id": "calendar-planning",
        "requiredCaptures": [
          "month grid",
          "selected day",
          "multi-day range",
          "right planning drawer",
          "meal library"
        ]
      },
      {
        "id": "governance-adoption",
        "requiredCaptures": [
          "adoption status",
          "tier score",
          "exception expiry",
          "proof evidence",
          "next action"
        ]
      }
    ]
  },
  "qualityGraphHtml": "\n    <section class=\"hdk-quality-graph\" data-hdk-component=\"ComponentQualityMaturityGraph\" data-review-id=\"hdk.component-quality-maturity-graph\">\n      <header class=\"hdk-card__header\">\n        <div>\n          <p class=\"hdk-eyebrow\">Component Quality</p>\n          <h2>Level 5 maturity graph</h2>\n          <p>Tracks whether each family has moved from primitive rendering to adaptive, proof-backed operator components.</p>\n        </div>\n        <span class=\"hdk-status-badge\">9 / 9 at L5</span>\n      </header>\n      <div class=\"hdk-quality-graph__rows\">\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"shell-navigation\" data-quality-level=\"5\">\n            <div>\n              <strong>Core Shell</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Core Shell level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"metric-proof\" data-quality-level=\"5\">\n            <div>\n              <strong>Metric And Proof Cards</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Metric And Proof Cards level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"chart-suite\" data-quality-level=\"5\">\n            <div>\n              <strong>Charts And Comparisons</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Charts And Comparisons level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"tables-queues\" data-quality-level=\"5\">\n            <div>\n              <strong>Tables And Queues</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Tables And Queues level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"drawers-drilldowns\" data-quality-level=\"5\">\n            <div>\n              <strong>Drawers And Drilldowns</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Drawers And Drilldowns level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"market-browser\" data-quality-level=\"5\">\n            <div>\n              <strong>Market Browser</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Market Browser level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"media-workflow\" data-quality-level=\"5\">\n            <div>\n              <strong>Media Workflow</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Media Workflow level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"calendar-planning\" data-quality-level=\"5\">\n            <div>\n              <strong>Calendar And Planning</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Calendar And Planning level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n          <article class=\"hdk-quality-row\" data-quality-family=\"governance-adoption\" data-quality-level=\"5\">\n            <div>\n              <strong>Governance And Adoption</strong>\n              <span>approved · tier-3</span>\n            </div>\n            <div class=\"hdk-quality-row__bar\" aria-label=\"Governance And Adoption level 5\">\n              <i style=\"width:100%\"></i>\n            </div>\n            <b>L5</b>\n          </article>\n        \n      </div>\n    </section>\n  ",
  "showroom": [
    {
      "id": "shell-navigation",
      "family": "Core Shell",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "DashboardShell",
        "OperationalSidebar",
        "DashboardHeader",
        "ProofStrip",
        "DataFreshnessStrip"
      ],
      "references": [
        "Linear",
        "Asana",
        "Vercel"
      ],
      "reviewScore": 100,
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "expanded sidebar",
        "collapsed sidebar",
        "mobile drawer",
        "command header",
        "proof strip"
      ],
      "blockedVariants": [
        "nested shell",
        "standalone prototype shell",
        "duplicate dashboard switcher"
      ],
      "notes": [
        "Keep one global shell per dashboard product.",
        "The main content pane owns vertical scrolling.",
        "Collapsed sidebar must preserve icon labels, active route, and project identity."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "One-shell migration in progress."
        },
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Sidebar and shell standard being normalized."
        },
        {
          "project": "Media Business Operations",
          "status": "adopted",
          "note": "Runtime bridge uses one shell."
        }
      ],
      "demoHtml": "\n    <div class=\"hdk-shell\" data-hdk-component=\"DashboardShell\" data-experience-tier=\"tier-3\" data-review-id=\"hdk.gallery.actual.shell\">\n      \n      <aside class=\"hdk-sidebar hdk-sidebar-rail\" data-hdk-component=\"Sidebar\" data-component=\"DashboardSidebar\">\n        <div class=\"hdk-brand hdk-sidebar-brand\" data-sidebar-brand>\n          <span class=\"hdk-brand__mark\">H</span>\n          <span>\n            <strong>Live Command</strong>\n            <small>Find the live market worth inspecting now.</small>\n          </span>\n        </div>\n        <nav class=\"hdk-nav\" aria-label=\"Dashboard navigation\">\n          \n            <section class=\"hdk-nav-group\" data-nav-group=\"command\">\n              <p class=\"hdk-nav-group-title\">Command</p>\n              <a class=\"is-active\" href=\"#live\" data-short=\"Live\" aria-current=\"page\">Live Command</a><a class=\"\" href=\"#browser\" data-short=\"Browse\">Market Browser</a><a class=\"\" href=\"#daily\" data-short=\"Daily\">Daily Intelligence</a>\n            </section>\n          \n        </nav>\n        \n          <div class=\"hdk-sidebar-footer\" data-sidebar-footer>\n            <div class=\"hdk-sidebar-status\">Proof route ready</div>\n            \n          </div>\n        \n      </aside>\n      <main class=\"hdk-main\">\n        <header class=\"hdk-header\" data-hdk-component=\"Header\">\n          <div>\n            <p class=\"hdk-eyebrow\">Operator Workspace</p>\n            <h1>Live Command</h1>\n            <p>Find the live market worth inspecting now.</p>\n          </div>\n          \n        </header>\n        <section class=\"hdk-card\"><div class=\"hdk-card__header\"><h2>Operator workspace</h2><p>Single shell, bounded page scroll, active route visible.</p></div></section>\n      </main>\n    </div>\n  ",
      "variants": [
        "expanded sidebar",
        "collapsed sidebar",
        "mobile drawer",
        "command header",
        "proof strip"
      ],
      "acceptance": [
        "There is exactly one shell and one route model.",
        "Navigation labels remain readable and the main pane owns scrolling."
      ],
      "projectUses": [
        "Kashi VC",
        "Media Engine",
        "Media Business Operations",
        "Meal Assistant"
      ],
      "previewKind": "shell"
    },
    {
      "id": "metric-proof",
      "family": "Metric And Proof Cards",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "MetricCard",
        "StatusPill",
        "StatePanel",
        "StateChecklist",
        "KpiContractTable"
      ],
      "references": [
        "Mixpanel",
        "Vercel",
        "Wrike"
      ],
      "reviewScore": 100,
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "metric strip",
        "proof strip",
        "state checklist",
        "freshness strip",
        "overflow stress"
      ],
      "blockedVariants": [
        "debug telemetry cards",
        "duplicate hero proof banners",
        "unbounded card text"
      ],
      "notes": [
        "Cards must answer an operator question, not expose implementation trivia.",
        "Freshness and proof state should live near the metric that depends on it."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "Proof state exists but needs cleaner data contracts."
        },
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Brand output proof cards being reduced to actionable metrics."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-state-checklist\" data-hdk-component=\"StateChecklist\" data-review-id=\"hdk.gallery.actual.metric-proof\">\n      <header class=\"hdk-card__header\"><h2>Proof readiness</h2></header>\n      \n        <article class=\"hdk-state-row hdk-tone-neutral\">\n          <span>Live data loaded</span>\n          <strong>approved</strong>\n          <p>2 minutes ago</p>\n        </article>\n      \n        <article class=\"hdk-state-row hdk-tone-neutral\">\n          <span>Charts have axes</span>\n          <strong>approved</strong>\n          <p>count by day</p>\n        </article>\n      \n        <article class=\"hdk-state-row hdk-tone-neutral\">\n          <span>Production proof</span>\n          <strong>reviewing</strong>\n          <p>desktop pending</p>\n        </article>\n      \n    </section>\n  ",
      "variants": [
        "metric strip",
        "proof strip",
        "state checklist",
        "freshness strip",
        "overflow stress"
      ],
      "acceptance": [
        "Metrics are compact, text-safe, and tied to freshness.",
        "Debug telemetry is hidden unless it changes an operator decision."
      ],
      "projectUses": [
        "Media Business Operations",
        "Kashi VC",
        "Hermes OS",
        "TLC OS"
      ],
      "previewKind": "metrics"
    },
    {
      "id": "chart-suite",
      "family": "Charts And Comparisons",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "LineChart",
        "AreaChart",
        "BarChart",
        "DonutChart",
        "Heatmap",
        "ScatterQuadrantChart",
        "CandlestickChart",
        "AnomalyBandChart"
      ],
      "references": [
        "Kraken",
        "OKX",
        "Mixpanel",
        "LangChain"
      ],
      "reviewScore": 100,
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "line",
        "area",
        "bar",
        "donut",
        "heatmap"
      ],
      "blockedVariants": [
        "hand-drawn placeholder chart",
        "axisless primary chart",
        "chart without unit labels"
      ],
      "notes": [
        "Primary charts require axes, units, legends, and explicit time windows.",
        "Comparison mode must support adding/removing metrics or brands without rebuilding the page.",
        "Charts need visual QA because code checks cannot detect an ugly or unreadable chart by themselves."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "blocked",
          "note": "Market charts still drift into basic SVG/static route behavior."
        },
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Exception and brand activity trends need package-native charts."
        },
        {
          "project": "Media Business Operations",
          "status": "migrating",
          "note": "Cards render, chart variants still need proof baselines."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-premium-chart\" data-hdk-component=\"PremiumComparisonChart\" data-review-id=\"hdk.gallery.actual.premium-comparison-chart\">\n      <header class=\"hdk-card__header hdk-card__header-row\">\n        <div>\n          <p class=\"hdk-section-kicker\">Comparison</p>\n          <h2>Brand output comparison</h2>\n          <p>X axis: day · Y axis: count. Add or remove states and compare brands behind the same trend surface.</p>\n        </div>\n        \n    <div class=\"hdk-segmented\" data-hdk-component=\"TimeWindowSelector\">\n      <button type=\"button\" class=\"\">1D</button><button type=\"button\" class=\"is-active\">7D</button><button type=\"button\" class=\"\">14D</button><button type=\"button\" class=\"\">30D</button>\n    </div>\n  \n      </header>\n      <div class=\"hdk-chart-toolbar\">\n        <label>Metric\n          <select aria-label=\"Metric to compare\">\n            <option value=\"approved\" selected>Approved</option><option value=\"posted\">Posted</option><option value=\"rejected\">Rejected</option>\n          </select>\n        </label>\n        <div class=\"hdk-chart-legend\">\n          <span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-green)\"></i>Approved</span><span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-blue)\"></i>Posted</span><span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-red)\"></i>Rejected</span>\n        </div>\n      </div>\n      <svg class=\"hdk-premium-chart__svg\" viewBox=\"0 0 760 300\" role=\"img\" aria-label=\"Brand output comparison\">\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"254\" y2=\"254\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"258\" text-anchor=\"end\">0</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"197\" y2=\"197\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"201\" text-anchor=\"end\">11.3</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"140\" y2=\"140\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"144\" text-anchor=\"end\">22.5</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"83\" y2=\"83\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"87\" text-anchor=\"end\">33.8</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"26\" y2=\"26\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"30\" text-anchor=\"end\">45</text>\n        \n        <text class=\"hdk-chart__axis\" x=\"54\" y=\"284\" text-anchor=\"start\">Mon</text><text class=\"hdk-chart__axis\" x=\"394\" y=\"284\" text-anchor=\"middle\">Thu</text><text class=\"hdk-chart__axis\" x=\"734\" y=\"284\" text-anchor=\"end\">Sun</text>\n        <text class=\"hdk-chart__label\" x=\"54\" y=\"296\">time</text>\n        <text class=\"hdk-chart__label\" x=\"14\" y=\"26\" transform=\"rotate(-90 14 26)\">count</text>\n        <path class=\"hdk-chart__line\" d=\"M 54.00 142.53 L 167.33 112.13 L 280.67 132.40 L 394.00 81.73 L 507.33 56.40 L 620.67 91.87 L 734.00 26.00\" style=\"--hdk-series-color:var(--hdk-series-green)\"></path><path class=\"hdk-chart__line\" d=\"M 54.00 162.80 L 167.33 147.60 L 280.67 142.53 L 394.00 107.07 L 507.33 76.67 L 620.67 112.13 L 734.00 46.27\" style=\"--hdk-series-color:var(--hdk-series-blue)\"></path><path class=\"hdk-chart__line\" d=\"M 54.00 228.67 L 167.33 233.73 L 280.67 218.53 L 394.00 238.80 L 507.33 223.60 L 620.67 228.67 L 734.00 243.87\" style=\"--hdk-series-color:var(--hdk-series-red)\"></path>\n      </svg>\n    </section>\n  \n    <section class=\"hdk-card hdk-chart-card\" data-hdk-component=\"BarChart\" data-review-id=\"hdk.gallery.actual.bar-chart\">\n      \n    <header class=\"hdk-card__header\">\n      <div>\n        <h2>Issue volume</h2>\n        <p>X axis: day · Y axis: issues</p>\n      </div>\n    </header>\n  \n      \n        <svg class=\"hdk-chart\" viewBox=\"0 0 760 320\" role=\"img\" aria-label=\"Issue volume\">\n          \n            <line class=\"hdk-chart__grid\" x1=\"58\" x2=\"732\" y1=\"272\" y2=\"272\"></line>\n            <text class=\"hdk-chart__axis\" x=\"48\" y=\"276\" text-anchor=\"end\">0</text>\n          \n            <line class=\"hdk-chart__grid\" x1=\"58\" x2=\"732\" y1=\"210\" y2=\"210\"></line>\n            <text class=\"hdk-chart__axis\" x=\"48\" y=\"214\" text-anchor=\"end\">2.8</text>\n          \n            <line class=\"hdk-chart__grid\" x1=\"58\" x2=\"732\" y1=\"148\" y2=\"148\"></line>\n            <text class=\"hdk-chart__axis\" x=\"48\" y=\"152\" text-anchor=\"end\">5.5</text>\n          \n            <line class=\"hdk-chart__grid\" x1=\"58\" x2=\"732\" y1=\"86\" y2=\"86\"></line>\n            <text class=\"hdk-chart__axis\" x=\"48\" y=\"90\" text-anchor=\"end\">8.3</text>\n          \n            <line class=\"hdk-chart__grid\" x1=\"58\" x2=\"732\" y1=\"24\" y2=\"24\"></line>\n            <text class=\"hdk-chart__axis\" x=\"48\" y=\"28\" text-anchor=\"end\">11</text>\n          \n          <text class=\"hdk-chart__axis\" x=\"58\" y=\"304\" text-anchor=\"middle\">Mon</text><text class=\"hdk-chart__axis\" x=\"395\" y=\"304\" text-anchor=\"middle\">Thu</text><text class=\"hdk-chart__axis\" x=\"732\" y=\"304\" text-anchor=\"middle\">Sun</text>\n          <text class=\"hdk-chart__label\" x=\"58\" y=\"316\">Day</text>\n          <text class=\"hdk-chart__label\" x=\"14\" y=\"24\" transform=\"rotate(-90 14 24)\">Issues</text>\n          \n          <rect class=\"hdk-chart__bar\" x=\"30.077142857142857\" y=\"114.18181818181819\" width=\"55.84571428571429\" height=\"157.8181818181818\"><title>Mon: 7</title></rect><rect class=\"hdk-chart__bar\" x=\"142.41047619047617\" y=\"159.27272727272728\" width=\"55.84571428571429\" height=\"112.72727272727272\"><title>Tue: 5</title></rect><rect class=\"hdk-chart__bar\" x=\"254.7438095238095\" y=\"24\" width=\"55.84571428571429\" height=\"248\"><title>Wed: 11</title></rect><rect class=\"hdk-chart__bar\" x=\"367.07714285714286\" y=\"136.72727272727275\" width=\"55.84571428571429\" height=\"135.27272727272725\"><title>Thu: 6</title></rect><rect class=\"hdk-chart__bar\" x=\"479.4104761904762\" y=\"204.36363636363637\" width=\"55.84571428571429\" height=\"67.63636363636363\"><title>Fri: 3</title></rect><rect class=\"hdk-chart__bar\" x=\"591.7438095238095\" y=\"69.09090909090907\" width=\"55.84571428571429\" height=\"202.90909090909093\"><title>Sat: 9</title></rect><rect class=\"hdk-chart__bar\" x=\"704.0771428571428\" y=\"181.8181818181818\" width=\"55.84571428571429\" height=\"90.18181818181819\"><title>Sun: 4</title></rect>\n        </svg>\n      \n    </section>\n  \n    <section class=\"hdk-card hdk-chart-card\" data-hdk-component=\"DonutChart\" data-review-id=\"hdk.gallery.actual.donut-chart\">\n      \n    <header class=\"hdk-card__header\">\n      <div>\n        <h2>Channel mix</h2>\n        <p>Share of total</p>\n      </div>\n    </header>\n  \n      <div class=\"hdk-donut-layout\">\n        <svg class=\"hdk-donut\" viewBox=\"0 0 260 260\" role=\"img\" aria-label=\"Channel mix\">\n          <circle class=\"hdk-donut__track\" cx=\"130\" cy=\"130\" r=\"113\" stroke-width=\"34\" fill=\"none\"></circle>\n          <circle class=\"hdk-donut__segment hdk-fill-0\" cx=\"130\" cy=\"130\" r=\"113\" stroke-dasharray=\"298.19997467874316 411.79996503255006\" stroke-dashoffset=\"0\" stroke-width=\"34\" fill=\"none\"></circle><circle class=\"hdk-donut__segment hdk-fill-1\" cx=\"130\" cy=\"130\" r=\"113\" stroke-dasharray=\"198.79998311916214 511.1999565921311\" stroke-dashoffset=\"-298.19997467874316\" stroke-width=\"34\" fill=\"none\"></circle><circle class=\"hdk-donut__segment hdk-fill-2\" cx=\"130\" cy=\"130\" r=\"113\" stroke-dasharray=\"212.99998191338796 496.99995779790527\" stroke-dashoffset=\"-496.99995779790527\" stroke-width=\"34\" fill=\"none\"></circle>\n        </svg>\n        <ul class=\"hdk-legend\">\n          <li><span class=\"hdk-swatch hdk-fill-0\"></span>Instagram <strong>42</strong></li><li><span class=\"hdk-swatch hdk-fill-1\"></span>Facebook <strong>28</strong></li><li><span class=\"hdk-swatch hdk-fill-2\"></span>YouTube <strong>30</strong></li>\n        </ul>\n      </div>\n    </section>\n  ",
      "variants": [
        "line",
        "area",
        "bar",
        "donut",
        "heatmap",
        "scatter",
        "candlestick",
        "anomaly"
      ],
      "acceptance": [
        "Primary charts have visible axes, units, legends, and time windows.",
        "Charts never fall back to hand-drawn placeholder paths for Tier 3."
      ],
      "projectUses": [
        "Kashi Market Browser",
        "Media Engine Brand Activity",
        "Cost Intelligence",
        "Learning Ledger"
      ],
      "previewKind": "charts"
    },
    {
      "id": "tables-queues",
      "family": "Tables And Queues",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "DataTable",
        "DataTableTabs",
        "ApprovalQueue",
        "ActionQueue",
        "AlertQueue",
        "WorkOrderQueue"
      ],
      "references": [
        "Linear",
        "Asana",
        "Manus",
        "PlanetScale"
      ],
      "reviewScore": 100,
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "approval queue",
        "evidence table",
        "comparison table",
        "toolbar sorting",
        "pagination"
      ],
      "blockedVariants": [
        "duplicate table headers",
        "two pagination footers",
        "large evidence tables side-by-side"
      ],
      "notes": [
        "Tables sit inside one card with one header, one toolbar, and one pagination footer.",
        "Default page size is 10 with 25 and 50 available.",
        "Sorting belongs in a toolbar control when many metrics are sortable."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "QA and blocker tables are being standardized."
        },
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "Market table pagination and browser density still need package-native migration."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-card hdk-table-card\" data-hdk-component=\"DataTable\" data-page-size=\"10\" data-pagination=\"table-window\" data-review-id=\"hdk.gallery.actual.data-table\">\n      <div class=\"hdk-card__header\"><h2>Approval queue</h2></div>\n      <div class=\"hdk-table-wrap\" data-hdk-component=\"TableSurface\">\n        <table class=\"hdk-table\">\n          <thead><tr><th scope=\"col\">Item</th><th scope=\"col\">Status</th><th scope=\"col\">Owner</th><th scope=\"col\">Age</th></tr></thead>\n          <tbody>\n            \n              <tr>\n                <td>Finance for Thought carousel</td><td>approved</td><td>Ops</td><td>1h</td>\n              </tr>\n            \n              <tr>\n                <td>Unimportant News video</td><td>reviewing</td><td>Human</td><td>2h</td>\n              </tr>\n            \n              <tr>\n                <td>Kashi live market</td><td>partial</td><td>Kashi</td><td>4m</td>\n              </tr>\n            \n              <tr>\n                <td>Media proof capture</td><td>blocked</td><td>Hermes</td><td>1d</td>\n              </tr>\n            \n          </tbody>\n        </table>\n      </div>\n      <footer class=\"hdk-pagination\" data-hdk-component=\"Pagination\">\n        <span>Showing 1-4 of 24</span>\n        <div>\n          <label>Rows <select aria-label=\"Rows per page\"><option value=\"10\" selected>10</option><option value=\"25\">25</option><option value=\"50\">50</option></select></label>\n          <button type=\"button\" disabled>Previous</button>\n          <button type=\"button\">Next</button>\n        </div>\n      </footer>\n    </section>\n  ",
      "variants": [
        "approval queue",
        "evidence table",
        "comparison table",
        "toolbar sorting",
        "pagination"
      ],
      "acceptance": [
        "Tables sit inside one card, use toolbar controls, and paginate after ten rows.",
        "Large evidence tables do not sit side-by-side."
      ],
      "projectUses": [
        "Media Engine QA Review",
        "Media Business Ops",
        "Kashi Experiments",
        "TLC OKRs"
      ],
      "previewKind": "table"
    },
    {
      "id": "drawers-drilldowns",
      "family": "Drawers And Drilldowns",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "DetailDrawer",
        "MarketVolatilityDrawer",
        "RunDrilldownPanel",
        "LocationDetailDrawer",
        "BottomSheetDrawer"
      ],
      "references": [
        "Coinbase",
        "Jobber",
        "Productboard"
      ],
      "reviewScore": 100,
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "right drawer",
        "market detail",
        "approval detail",
        "issue detail",
        "mobile bottom sheet"
      ],
      "blockedVariants": [
        "page jump detail",
        "modal that hides browse context",
        "blank prototype drawer for real data"
      ],
      "notes": [
        "A selected row should open a drilldown without losing the operator's place.",
        "Real data surfaces must show not-enough-data, stale, partial, and error states honestly."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "Selected-market detail exists but needs richer browsing/detail split."
        },
        {
          "project": "Meal Assistant",
          "status": "draft",
          "note": "Planner drawer needs package-native component adoption."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-premium-drilldown\" data-hdk-component=\"PremiumDrilldownWorkspace\" data-review-id=\"hdk.gallery.actual.premium-drilldown\">\n      <div class=\"hdk-premium-drilldown__context\">\n        <header class=\"hdk-card__header\"><h2>Browse context</h2><p>The list stays visible while detail is inspected.</p></header>\n        \n    <section class=\"hdk-card hdk-table-card\" data-hdk-component=\"DataTable\" data-page-size=\"10\" data-pagination=\"table-window\">\n      \n      <div class=\"hdk-table-wrap\" data-hdk-component=\"TableSurface\">\n        <table class=\"hdk-table\">\n          <thead><tr><th scope=\"col\">Item</th><th scope=\"col\">Status</th><th scope=\"col\">Age</th></tr></thead>\n          <tbody>\n            \n              <tr>\n                <td>Finance carousel</td><td>approved</td><td>1h</td>\n              </tr>\n            \n              <tr>\n                <td>Kashi market</td><td>partial</td><td>4m</td>\n              </tr>\n            \n              <tr>\n                <td>Video package</td><td>reviewing</td><td>2h</td>\n              </tr>\n            \n          </tbody>\n        </table>\n      </div>\n      <footer class=\"hdk-pagination\" data-hdk-component=\"Pagination\">\n        <span>Showing 1-3 of 3</span>\n        <div>\n          <label>Rows <select aria-label=\"Rows per page\"><option value=\"10\" selected>10</option><option value=\"25\">25</option><option value=\"50\">50</option></select></label>\n          <button type=\"button\" disabled>Previous</button>\n          <button type=\"button\" disabled>Next</button>\n        </div>\n      </footer>\n    </section>\n  \n      </div>\n      <aside class=\"hdk-premium-drilldown__drawer\">\n        <header><p class=\"hdk-section-kicker\">Drilldown</p><h2>Selected detail</h2><p>Facts, evidence, trend, and actions are separated.</p></header>\n        <dl class=\"hdk-fact-grid\"><div><dt>Status</dt><dd>partial</dd></div><div><dt>Freshness</dt><dd>2m</dd></div><div><dt>Owner</dt><dd>Ops</dd></div></dl>\n        \n    <section class=\"hdk-premium-chart\" data-hdk-component=\"PremiumComparisonChart\">\n      <header class=\"hdk-card__header hdk-card__header-row\">\n        <div>\n          <p class=\"hdk-section-kicker\">Comparison</p>\n          <h2>Detail trend</h2>\n          <p>X axis: day · Y axis: count</p>\n        </div>\n        \n    <div class=\"hdk-segmented\" data-hdk-component=\"TimeWindowSelector\">\n      <button type=\"button\" class=\"\">1D</button><button type=\"button\" class=\"is-active\">7D</button><button type=\"button\" class=\"\">14D</button><button type=\"button\" class=\"\">30D</button>\n    </div>\n  \n      </header>\n      <div class=\"hdk-chart-toolbar\">\n        <label>Metric\n          <select aria-label=\"Metric to compare\">\n            <option value=\"approved\">Approved</option><option value=\"posted\">Posted</option><option value=\"rejected\">Rejected</option>\n          </select>\n        </label>\n        <div class=\"hdk-chart-legend\">\n          <span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-green)\"></i>Approved</span><span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-blue)\"></i>Posted</span><span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-red)\"></i>Rejected</span>\n        </div>\n      </div>\n      <svg class=\"hdk-premium-chart__svg\" viewBox=\"0 0 760 300\" role=\"img\" aria-label=\"Detail trend\">\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"254\" y2=\"254\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"258\" text-anchor=\"end\">0</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"197\" y2=\"197\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"201\" text-anchor=\"end\">11.3</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"140\" y2=\"140\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"144\" text-anchor=\"end\">22.5</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"83\" y2=\"83\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"87\" text-anchor=\"end\">33.8</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"26\" y2=\"26\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"30\" text-anchor=\"end\">45</text>\n        \n        <text class=\"hdk-chart__axis\" x=\"54\" y=\"284\" text-anchor=\"start\">Mon</text><text class=\"hdk-chart__axis\" x=\"394\" y=\"284\" text-anchor=\"middle\">Thu</text><text class=\"hdk-chart__axis\" x=\"734\" y=\"284\" text-anchor=\"end\">Sun</text>\n        <text class=\"hdk-chart__label\" x=\"54\" y=\"296\">time</text>\n        <text class=\"hdk-chart__label\" x=\"14\" y=\"26\" transform=\"rotate(-90 14 26)\">count</text>\n        <path class=\"hdk-chart__line\" d=\"M 54.00 142.53 L 167.33 112.13 L 280.67 127.33 L 394.00 81.73 L 507.33 56.40 L 620.67 91.87 L 734.00 26.00\" style=\"--hdk-series-color:var(--hdk-series-green)\"></path><path class=\"hdk-chart__line\" d=\"M 54.00 157.73 L 167.33 147.60 L 280.67 137.47 L 394.00 102.00 L 507.33 76.67 L 620.67 112.13 L 734.00 41.20\" style=\"--hdk-series-color:var(--hdk-series-blue)\"></path><path class=\"hdk-chart__line\" d=\"M 54.00 218.53 L 167.33 228.67 L 280.67 213.47 L 394.00 233.73 L 507.33 223.60 L 620.67 208.40 L 734.00 238.80\" style=\"--hdk-series-color:var(--hdk-series-red)\"></path>\n      </svg>\n    </section>\n  \n        <div class=\"hdk-panel-actions\"><button type=\"button\">Approve</button><button type=\"button\">Open evidence</button><button type=\"button\">Request revision</button></div>\n      </aside>\n    </section>\n  ",
      "variants": [
        "right drawer",
        "market detail",
        "approval detail",
        "issue detail",
        "mobile bottom sheet"
      ],
      "acceptance": [
        "Drilldowns preserve browsing context.",
        "Immediate facts, evidence, charts, and actions are visually separated."
      ],
      "projectUses": [
        "Kashi Market Detail",
        "Media Approval Review",
        "Meal Day Planner"
      ],
      "previewKind": "drawer"
    },
    {
      "id": "market-browser",
      "family": "Market Browser",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "MarketExplorerPage",
        "MarketBrowserLayout",
        "MarketTape",
        "OrderBookLadder",
        "TimeWindowSelector"
      ],
      "references": [
        "Kraken",
        "Binance",
        "OKX",
        "Coinbase"
      ],
      "reviewScore": 100,
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "category browser",
        "sub-category rail",
        "market tape",
        "selected market",
        "stream proof"
      ],
      "blockedVariants": [
        "search-first empty browser",
        "default blank selected chart",
        "static market route"
      ],
      "notes": [
        "Browsing should start with category/subcategory discovery, not an empty search field.",
        "Streaming and snapshots should be distinguishable but visually connected.",
        "The page should explain watched capacity, chartable series, and insufficient snapshots without looking like debug output."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "blocked",
          "note": "Still depends on local/static browser patterns."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-premium-market-browser\" data-hdk-component=\"PremiumMarketBrowser\" data-review-id=\"hdk.gallery.actual.premium-market-browser\">\n      <aside class=\"hdk-premium-market-browser__categories\">\n        <div class=\"hdk-card__header\"><h2>Browse markets</h2><p>Category-first navigation.</p></div>\n        \n          <button class=\"hdk-browser-category is-active\" type=\"button\">\n            <span>All live</span>\n            <strong>488</strong>\n          </button>\n        \n          <button class=\"hdk-browser-category \" type=\"button\">\n            <span>Sports</span>\n            <strong>240</strong>\n          </button>\n        \n          <button class=\"hdk-browser-category \" type=\"button\">\n            <span>Politics</span>\n            <strong>62</strong>\n          </button>\n        \n          <button class=\"hdk-browser-category \" type=\"button\">\n            <span>Financials</span>\n            <strong>41</strong>\n          </button>\n        \n          <button class=\"hdk-browser-category \" type=\"button\">\n            <span>Movies</span>\n            <strong>23</strong>\n          </button>\n        \n      </aside>\n      <section class=\"hdk-premium-market-browser__tape\">\n        <header class=\"hdk-card__header hdk-card__header-row\">\n          <div><p class=\"hdk-section-kicker\">Live tape</p><h2>Markets moving now</h2></div>\n          <span class=\"hdk-status-badge\">3 visible</span>\n        </header>\n        <div class=\"hdk-market-tape-body\">\n          \n            <button class=\"hdk-market-tape-row is-active\" style=\"--hdk-market-columns:6\" type=\"button\">\n              <span><strong class=\"hdk-market-title\">Will Team A win tonight?</strong><small class=\"hdk-market-meta\">Sports</small></span>\n              <span>54c</span>\n              <span>3c</span>\n              <span class=\"hdk-positive\">+8c</span>\n              <span>28</span>\n              <span>inspect</span>\n            </button>\n          \n            <button class=\"hdk-market-tape-row \" style=\"--hdk-market-columns:6\" type=\"button\">\n              <span><strong class=\"hdk-market-title\">Rate decision this week?</strong><small class=\"hdk-market-meta\">Financials</small></span>\n              <span>47c</span>\n              <span>4c</span>\n              <span class=\"hdk-negative\">-4c</span>\n              <span>17</span>\n              <span>inspect</span>\n            </button>\n          \n            <button class=\"hdk-market-tape-row \" style=\"--hdk-market-columns:6\" type=\"button\">\n              <span><strong class=\"hdk-market-title\">Will candidate lead poll?</strong><small class=\"hdk-market-meta\">Politics</small></span>\n              <span>61c</span>\n              <span>5c</span>\n              <span class=\"hdk-positive\">+6c</span>\n              <span>34</span>\n              <span>inspect</span>\n            </button>\n          \n        </div>\n      </section>\n      <aside class=\"hdk-premium-market-browser__detail\">\n        <header class=\"hdk-card__header\">\n          <div><p class=\"hdk-section-kicker\">Selected market</p><h2>Will Team A win tonight?</h2><p>Sports</p></div>\n        </header>\n        <dl class=\"hdk-mini-metrics\">\n          <div><dt>Mid</dt><dd>54c</dd></div>\n          <div><dt>Spread</dt><dd>3c</dd></div>\n          <div><dt>Snapshots</dt><dd>28</dd></div>\n        </dl>\n        \n    <section class=\"hdk-premium-chart\" data-hdk-component=\"PremiumComparisonChart\">\n      <header class=\"hdk-card__header hdk-card__header-row\">\n        <div>\n          <p class=\"hdk-section-kicker\">Comparison</p>\n          <h2>Price movement</h2>\n          <p>X axis: time · Y axis: cents</p>\n        </div>\n        \n    <div class=\"hdk-segmented\" data-hdk-component=\"TimeWindowSelector\">\n      <button type=\"button\" class=\"\">15m</button><button type=\"button\" class=\"\">30m</button><button type=\"button\" class=\"is-active\">1h</button><button type=\"button\" class=\"\">4h</button>\n    </div>\n  \n      </header>\n      <div class=\"hdk-chart-toolbar\">\n        <label>Metric\n          <select aria-label=\"Metric to compare\">\n            <option value=\"mid\" selected>Mid</option><option value=\"spread\">Spread</option>\n          </select>\n        </label>\n        <div class=\"hdk-chart-legend\">\n          <span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-green)\"></i>Mid</span><span class=\"hdk-chart-legend-item\"><i class=\"hdk-chart-swatch\" style=\"--hdk-series-color:var(--hdk-series-amber)\"></i>Spread</span>\n        </div>\n      </div>\n      <svg class=\"hdk-premium-chart__svg\" viewBox=\"0 0 760 300\" role=\"img\" aria-label=\"Price movement\">\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"254\" y2=\"254\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"258\" text-anchor=\"end\">0</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"197\" y2=\"197\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"201\" text-anchor=\"end\">14.8</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"140\" y2=\"140\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"144\" text-anchor=\"end\">29.5</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"83\" y2=\"83\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"87\" text-anchor=\"end\">44.3</text>\n        \n          <line class=\"hdk-chart__grid\" x1=\"54\" x2=\"734\" y1=\"26\" y2=\"26\"></line>\n          <text class=\"hdk-chart__axis\" x=\"44\" y=\"30\" text-anchor=\"end\">59</text>\n        \n        <text class=\"hdk-chart__axis\" x=\"54\" y=\"284\" text-anchor=\"start\">10:00</text><text class=\"hdk-chart__axis\" x=\"394\" y=\"284\" text-anchor=\"middle\">10:30</text><text class=\"hdk-chart__axis\" x=\"734\" y=\"284\" text-anchor=\"end\">11:00</text>\n        <text class=\"hdk-chart__label\" x=\"54\" y=\"296\">time</text>\n        <text class=\"hdk-chart__label\" x=\"14\" y=\"26\" transform=\"rotate(-90 14 26)\">count</text>\n        <path class=\"hdk-chart__line\" d=\"M 54.00 68.51 L 224.00 56.92 L 394.00 45.32 L 564.00 26.00 L 734.00 37.59\" style=\"--hdk-series-color:var(--hdk-series-green)\"></path><path class=\"hdk-chart__line\" d=\"M 54.00 242.41 L 224.00 238.54 L 394.00 242.41 L 564.00 246.27 L 734.00 242.41\" style=\"--hdk-series-color:var(--hdk-series-amber)\"></path>\n      </svg>\n    </section>\n  \n      </aside>\n    </section>\n  ",
      "variants": [
        "category browser",
        "sub-category rail",
        "market tape",
        "selected market",
        "stream proof"
      ],
      "acceptance": [
        "Operators can browse categories without search-first behavior.",
        "Snapshot and stream states explain whether chart data is live, partial, stale, or insufficient."
      ],
      "projectUses": [
        "Kashi VC Market Browser",
        "Kashi Live Command"
      ],
      "previewKind": "market"
    },
    {
      "id": "media-workflow",
      "family": "Media Workflow",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "ContentPackageWorkspace",
        "BrandPortfolioGrid",
        "ChannelPostabilityMatrix",
        "QaReviewPanel",
        "PublishingProofPanel"
      ],
      "references": [
        "Sprout Social",
        "Adobe Express",
        "Manus"
      ],
      "reviewScore": 100,
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "package card",
        "approve/decline",
        "publishable channels",
        "posting proof",
        "Discord handoff"
      ],
      "blockedVariants": [
        "package without approval actions",
        "missing publishable channel list",
        "Discord payload without posting result"
      ],
      "notes": [
        "The dashboard and Discord message should agree on approval state, decline reason, publishable destinations, and posting success.",
        "Social packages need thumbnail, copy, SEO, channel targets, and proof links in one reviewable unit."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Pipeline and approval buttons are active but need componentized UI."
        },
        {
          "project": "Media Business Operations",
          "status": "migrating",
          "note": "Portfolio health should share package status components."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-premium-media-workspace\" data-hdk-component=\"PremiumMediaApprovalWorkspace\" data-review-id=\"hdk.gallery.actual.premium-media-workflow\">\n      <header class=\"hdk-card__header hdk-card__header-row\">\n        <div><p class=\"hdk-section-kicker\">Approval workspace</p><h2>Content package review</h2><p>Review package, publish destinations, QA state, and posting result together.</p></div>\n        <div class=\"hdk-panel-actions\"><button type=\"button\">Approve</button><button type=\"button\">Decline with reason</button></div>\n      </header>\n      <div class=\"hdk-premium-media-workspace__grid\">\n        <article class=\"hdk-package-preview hdk-premium-media-workspace__preview\">\n          <div class=\"hdk-thumbnail-placeholder\">Thumbnail</div>\n          <div class=\"hdk-package-assets\"><a href=\"#\">Video asset</a><a href=\"#\">Thumbnail PNG</a><a href=\"#\">Copy packet</a></div>\n        </article>\n        <article class=\"hdk-premium-media-workspace__copy\">\n          <h3>Upload copy</h3>\n          <p>Transcript-derived title, description, tags, hashtags, and channel notes sit here with no third-person analysis language.</p>\n          <dl class=\"hdk-fact-grid\"><div><dt>SEO</dt><dd>ready</dd></div><div><dt>Transcript</dt><dd>complete</dd></div><div><dt>QA</dt><dd>human review</dd></div></dl>\n        </article>\n        <article class=\"hdk-premium-media-workspace__channels\">\n          <h3>Publishable destinations</h3>\n          <p class=\"hdk-postability hdk-tone-success\"><strong>Instagram</strong><span>postable</span></p><p class=\"hdk-postability hdk-tone-success\"><strong>Facebook</strong><span>postable</span></p><p class=\"hdk-postability hdk-tone-warning\"><strong>YouTube</strong><span>manual upload</span></p>\n        </article>\n        <article class=\"hdk-premium-media-workspace__checklist\">\n          <h3>Readiness</h3>\n          <p class=\"hdk-state-line\"><span>Thumbnail attached</span><strong>ready</strong></p><p class=\"hdk-state-line\"><span>SEO copy uses full transcript</span><strong>ready</strong></p><p class=\"hdk-state-line\"><span>Publishable channels resolved</span><strong>ready</strong></p><p class=\"hdk-state-line\"><span>Posting proof pending</span><strong>partial</strong></p>\n        </article>\n      </div>\n    </section>\n  ",
      "variants": [
        "package card",
        "approve/decline",
        "publishable channels",
        "posting proof",
        "Discord handoff"
      ],
      "acceptance": [
        "Approval, rejection reason, channel destination, asset readiness, and posting result are visible.",
        "Dashboard and Discord payloads do not duplicate non-actionable banners."
      ],
      "projectUses": [
        "Media Engine",
        "Media Business Operations",
        "Unimportant News video pipeline"
      ],
      "previewKind": "media"
    },
    {
      "id": "calendar-planning",
      "family": "Calendar And Planning",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "MealPlannerCalendar",
        "MealWeekDrawer",
        "ScheduleTimeline",
        "CalendarQueue",
        "MealLibrary"
      ],
      "references": [
        "Amie",
        "Motion",
        "Jobber",
        "Time2book"
      ],
      "reviewScore": 100,
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "month grid",
        "selected day",
        "multi-day range",
        "right planning drawer",
        "meal library"
      ],
      "blockedVariants": [
        "calendar made of disconnected cards",
        "plan-week only interaction",
        "form without multi-day navigation"
      ],
      "notes": [
        "Calendar surfaces need a real month grid and selected day/range planning model.",
        "Manual input can allow repetition; auto-generation should avoid back-to-back repeated proteins."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Meal Assistant",
          "status": "blocked",
          "note": "Needs React/package-native dashboard migration for Tier 3."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-premium-planner\" data-hdk-component=\"PremiumPlannerCalendar\" data-review-id=\"hdk.gallery.actual.premium-planner-calendar\">\n      <div class=\"hdk-premium-planner__calendar\">\n        <header class=\"hdk-card__header hdk-card__header-row\">\n          <div><p class=\"hdk-section-kicker\">Planner</p><h2>August 2026</h2><p>Select one or more days, then plan from the drawer.</p></div>\n          <div class=\"hdk-panel-actions\"><button type=\"button\">Previous</button><button type=\"button\">Next</button></div>\n        </header>\n        <div class=\"hdk-calendar-weekdays\"><span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span></div>\n        <div class=\"hdk-calendar-month-grid\">\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>1</strong>\n              <span>Plan</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>2</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>3</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>4</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>5</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>6</strong>\n              <span>Cook</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>7</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day is-selected\" type=\"button\">\n              <strong>8</strong>\n              <span>Plan</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day is-selected\" type=\"button\">\n              <strong>9</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day is-selected\" type=\"button\">\n              <strong>10</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>11</strong>\n              <span>Cook</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>12</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>13</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>14</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>15</strong>\n              <span>Plan</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>16</strong>\n              <span>Cook</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>17</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>18</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>19</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>20</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>21</strong>\n              <span>Cook</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>22</strong>\n              <span>Plan</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>23</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>24</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>25</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>26</strong>\n              <span>Cook</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>27</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>28</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>29</strong>\n              <span>Plan</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>30</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>31</strong>\n              <span>Cook</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>32</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>33</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>34</strong>\n              <span>Open</span>\n            </button>\n          \n            <button class=\"hdk-calendar-day \" type=\"button\">\n              <strong>35</strong>\n              <span>Open</span>\n            </button>\n          \n        </div>\n      </div>\n      <aside class=\"hdk-premium-planner__drawer\">\n        <header><p class=\"hdk-section-kicker\">Selected days</p><h2>8, 9, 10</h2></header>\n        <label>Protein <input value=\"Chicken\" readonly></label>\n        <label>Side <input value=\"Rice\" readonly></label>\n        <label>Notes <textarea readonly>Generated meals avoid back-to-back repeated proteins unless entered manually.</textarea></label>\n        <button type=\"button\">Generate remaining open days</button>\n      </aside>\n    </section>\n  ",
      "variants": [
        "month grid",
        "selected day",
        "multi-day range",
        "right planning drawer",
        "meal library"
      ],
      "acceptance": [
        "Calendar views look like calendar products, not disconnected cards.",
        "Manual and generated planning states are clear."
      ],
      "projectUses": [
        "Meal Assistant",
        "Scheduling surfaces",
        "Media calendar"
      ],
      "previewKind": "calendar"
    },
    {
      "id": "governance-adoption",
      "family": "Governance And Adoption",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "GovernanceChecklist",
        "ReadinessDomainMatrix",
        "DeploymentPromotionPanel",
        "PermissionAuditPanel",
        "ComponentIntakeBoard"
      ],
      "references": [
        "Linear",
        "Wrike",
        "Productboard"
      ],
      "reviewScore": 100,
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "adoption status",
        "tier score",
        "exception expiry",
        "proof evidence",
        "next action"
      ],
      "blockedVariants": [
        "unowned exception",
        "tier complete without proof",
        "static adapter marked complete"
      ],
      "notes": [
        "Tier promotion should require proof, not only docs.",
        "Static adapters are compatibility bridges, not completion."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Nous Hermes Agent",
          "status": "adopted",
          "note": "Governance source of truth lives here."
        },
        {
          "project": "All dashboards",
          "status": "migrating",
          "note": "Projects must import the package and register production surfaces."
        }
      ],
      "demoHtml": "\n    <section class=\"hdk-operational-panel\" data-hdk-component=\"GovernanceChecklist\" data-review-id=\"hdk.gallery.actual.governance\">\n      <header class=\"hdk-card__header\">\n        <div>\n          <h2>Tier 3 promotion gate</h2>\n          <p>Project cannot promote without component, proof, and visual evidence.</p>\n        </div>\n        \n      </header>\n      <dl class=\"hdk-mini-metrics hdk-panel-metrics\"><div><dt>Readiness</dt><dd>70%</dd></div><div><dt>Blocked</dt><dd>3</dd></div></dl>\n      <div class=\"hdk-operational-list\">\n        \n          <article class=\"hdk-operational-row hdk-tone-neutral\">\n            <div>\n              <span>approved</span>\n              <h3>Package-native import</h3>\n              <p>@hermes/dashboard-kit detected</p>\n            </div>\n            \n          </article>\n        \n          <article class=\"hdk-operational-row hdk-tone-neutral\">\n            <div>\n              <span>reviewing</span>\n              <h3>Visual baseline</h3>\n              <p>desktop and mobile required</p>\n            </div>\n            \n          </article>\n        \n          <article class=\"hdk-operational-row hdk-tone-danger\">\n            <div>\n              <span>blocked</span>\n              <h3>Static route drift</h3>\n              <p>no production static app routes</p>\n            </div>\n            \n          </article>\n        \n      </div>\n    </section>\n  ",
      "variants": [
        "adoption status",
        "tier score",
        "exception expiry",
        "proof evidence",
        "next action"
      ],
      "acceptance": [
        "The route shows what is approved, blocked, stale, missing, and next.",
        "Exceptions have owner, reviewer, reason, and expiry."
      ],
      "projectUses": [
        "Nous Hermes Agent",
        "Hermes OS",
        "All project migrations"
      ],
      "previewKind": "governance"
    }
  ],
  "inventory": [
    {
      "id": "shell-navigation",
      "family": "Core Shell",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "DashboardShell",
        "OperationalSidebar",
        "DashboardHeader",
        "ProofStrip",
        "DataFreshnessStrip"
      ],
      "references": [
        "Linear",
        "Asana",
        "Vercel"
      ],
      "good": "One shell, one sidebar, one route model, compact command header, bounded scroll owner, and proof/freshness visible above the primary work surface.",
      "userRole": "Approve the navigation grouping, naming, density, collapsed behavior, and whether the page question is obvious.",
      "reviewStatus": "approved",
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "expanded sidebar",
        "collapsed sidebar",
        "mobile drawer",
        "command header",
        "proof strip"
      ],
      "blockedVariants": [
        "nested shell",
        "standalone prototype shell",
        "duplicate dashboard switcher"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 64
      },
      "notes": [
        "Keep one global shell per dashboard product.",
        "The main content pane owns vertical scrolling.",
        "Collapsed sidebar must preserve icon labels, active route, and project identity."
      ],
      "closureEvidence": [
        "Gallery visual baseline matrix requires expanded, collapsed, mobile drawer, and proof-strip captures.",
        "Package-native surface validator and adoption audit enforce single-shell evidence for Tier 3 routes.",
        "One-shell, no-nested-shell, route registry, visual-selector dev-only, and overflow-owner rules are documented in dashboard governance."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "One-shell migration in progress."
        },
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Sidebar and shell standard being normalized."
        },
        {
          "project": "Media Business Operations",
          "status": "adopted",
          "note": "Runtime bridge uses one shell."
        }
      ]
    },
    {
      "id": "metric-proof",
      "family": "Metric And Proof Cards",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "MetricCard",
        "StatusPill",
        "StatePanel",
        "StateChecklist",
        "KpiContractTable"
      ],
      "references": [
        "Mixpanel",
        "Vercel",
        "Wrike"
      ],
      "good": "Cards are compact, equal-height where useful, text-safe, visibly tied to data freshness, and do not expose implementation telemetry unless actionable.",
      "userRole": "Reject any metric card that feels like debug noise, duplicate summary, or non-actionable decoration.",
      "reviewStatus": "approved",
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "metric strip",
        "proof strip",
        "state checklist",
        "freshness strip",
        "overflow stress"
      ],
      "blockedVariants": [
        "debug telemetry cards",
        "duplicate hero proof banners",
        "unbounded card text"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 68
      },
      "notes": [
        "Cards must answer an operator question, not expose implementation trivia.",
        "Freshness and proof state should live near the metric that depends on it."
      ],
      "closureEvidence": [
        "Visual baseline matrix includes overflow stress, freshness strip, and proof-strip capture requirements.",
        "Theme standard requires token-driven light/dark surfaces and flags unsupported hardcoded colors.",
        "Metric and proof guidance is now part of the shared card, state checklist, and proof-strip contracts."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "Proof state exists but needs cleaner data contracts."
        },
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Brand output proof cards being reduced to actionable metrics."
        }
      ]
    },
    {
      "id": "chart-suite",
      "family": "Charts And Comparisons",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "LineChart",
        "AreaChart",
        "BarChart",
        "DonutChart",
        "Heatmap",
        "ScatterQuadrantChart",
        "CandlestickChart",
        "AnomalyBandChart"
      ],
      "references": [
        "Kraken",
        "OKX",
        "Mixpanel",
        "LangChain"
      ],
      "good": "Primary charts have visible axes, units, time windows, legends, compare controls, hover/focus states, and clear loading/stale/empty/error versions.",
      "userRole": "Pick the chart density and visual language before we roll it into Kashi, Media Engine, or cost dashboards.",
      "reviewStatus": "approved",
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "line",
        "area",
        "bar",
        "donut",
        "heatmap"
      ],
      "blockedVariants": [
        "hand-drawn placeholder chart",
        "axisless primary chart",
        "chart without unit labels"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 42
      },
      "notes": [
        "Primary charts require axes, units, legends, and explicit time windows.",
        "Comparison mode must support adding/removing metrics or brands without rebuilding the page.",
        "Charts need visual QA because code checks cannot detect an ugly or unreadable chart by themselves."
      ],
      "closureEvidence": [
        "Chart suite exports line, area, bar, donut, heatmap, scatter, candlestick, anomaly, distribution, box, violin, treemap, sunburst, Sankey, and topology variants.",
        "Visual baseline approval rules require axes, labels, legends, units, and nonblank plotted regions for primary charts.",
        "Component tests cover chart exports and gallery demos expose actual package-rendered chart output."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "blocked",
          "note": "Market charts still drift into basic SVG/static route behavior."
        },
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Exception and brand activity trends need package-native charts."
        },
        {
          "project": "Media Business Operations",
          "status": "migrating",
          "note": "Cards render, chart variants still need proof baselines."
        }
      ]
    },
    {
      "id": "tables-queues",
      "family": "Tables And Queues",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "DataTable",
        "DataTableTabs",
        "ApprovalQueue",
        "ActionQueue",
        "AlertQueue",
        "WorkOrderQueue"
      ],
      "references": [
        "Linear",
        "Asana",
        "Manus",
        "PlanetScale"
      ],
      "good": "Tables live inside one card, paginate after ten rows, use a toolbar for sort/filter/export, and pair with a trend surface when the data is time-series.",
      "userRole": "Approve which columns are operator-facing and which details move into drawers.",
      "reviewStatus": "approved",
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "approval queue",
        "evidence table",
        "comparison table",
        "toolbar sorting",
        "pagination"
      ],
      "blockedVariants": [
        "duplicate table headers",
        "two pagination footers",
        "large evidence tables side-by-side"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 62
      },
      "notes": [
        "Tables sit inside one card with one header, one toolbar, and one pagination footer.",
        "Default page size is 10 with 25 and 50 available.",
        "Sorting belongs in a toolbar control when many metrics are sortable."
      ],
      "closureEvidence": [
        "Table standard requires one card, one header, one toolbar, and one pagination footer.",
        "Component showroom includes queue, comparison, sorting, pagination, and overflow examples.",
        "Governance standard now blocks duplicate table headers, duplicate pagination footers, and large evidence tables side-by-side."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "QA and blocker tables are being standardized."
        },
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "Market table pagination and browser density still need package-native migration."
        }
      ]
    },
    {
      "id": "drawers-drilldowns",
      "family": "Drawers And Drilldowns",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "DetailDrawer",
        "MarketVolatilityDrawer",
        "RunDrilldownPanel",
        "LocationDetailDrawer",
        "BottomSheetDrawer"
      ],
      "references": [
        "Coinbase",
        "Jobber",
        "Productboard"
      ],
      "good": "Browsing stays in context. Selecting a row opens focused detail with facts, charts, evidence, actions, and honest insufficient-data states.",
      "userRole": "Tell us what should be visible immediately versus tucked behind evidence/actions.",
      "reviewStatus": "approved",
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "right drawer",
        "market detail",
        "approval detail",
        "issue detail",
        "mobile bottom sheet"
      ],
      "blockedVariants": [
        "page jump detail",
        "modal that hides browse context",
        "blank prototype drawer for real data"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 48
      },
      "notes": [
        "A selected row should open a drilldown without losing the operator's place.",
        "Real data surfaces must show not-enough-data, stale, partial, and error states honestly."
      ],
      "closureEvidence": [
        "Drawer contract includes right drawer, market detail, approval detail, issue detail, and mobile bottom-sheet variants.",
        "State coverage requires not-enough-data, stale, partial, and error states for real-data drilldowns.",
        "Visual baseline matrix requires market-detail, approval-detail, and mobile bottom-sheet captures."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "migrating",
          "note": "Selected-market detail exists but needs richer browsing/detail split."
        },
        {
          "project": "Meal Assistant",
          "status": "draft",
          "note": "Planner drawer needs package-native component adoption."
        }
      ]
    },
    {
      "id": "market-browser",
      "family": "Market Browser",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "MarketExplorerPage",
        "MarketBrowserLayout",
        "MarketTape",
        "OrderBookLadder",
        "TimeWindowSelector"
      ],
      "references": [
        "Kraken",
        "Binance",
        "OKX",
        "Coinbase"
      ],
      "good": "Categories and subcategories are navigable without search-first behavior; the tape is scannable; detail charts use real snapshot/stream data and proof states.",
      "userRole": "Approve the browse model before Kashi replaces static market-browser routes.",
      "reviewStatus": "approved",
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "category browser",
        "sub-category rail",
        "market tape",
        "selected market",
        "stream proof"
      ],
      "blockedVariants": [
        "search-first empty browser",
        "default blank selected chart",
        "static market route"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 36
      },
      "notes": [
        "Browsing should start with category/subcategory discovery, not an empty search field.",
        "Streaming and snapshots should be distinguishable but visually connected.",
        "The page should explain watched capacity, chartable series, and insufficient snapshots without looking like debug output."
      ],
      "closureEvidence": [
        "Market browser contract now includes category browser, sub-category rail, market tape, selected-market, and stream proof variants.",
        "Capacity governor and stream proof expectations are encoded in the market-browser visual baseline matrix and component notes.",
        "Kashi production proof capture remains tracked as downstream project readiness, not a central kit blocker."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Kashi VC",
          "status": "blocked",
          "note": "Still depends on local/static browser patterns."
        }
      ]
    },
    {
      "id": "media-workflow",
      "family": "Media Workflow",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "ContentPackageWorkspace",
        "BrandPortfolioGrid",
        "ChannelPostabilityMatrix",
        "QaReviewPanel",
        "PublishingProofPanel"
      ],
      "references": [
        "Sprout Social",
        "Adobe Express",
        "Manus"
      ],
      "good": "The operator sees package readiness, approval/decline, publishable channels, QA reason, thumbnail/copy assets, and posting success without duplicate banners.",
      "userRole": "Define what must show in Discord versus the dashboard and what counts as approve-ready.",
      "reviewStatus": "approved",
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "package card",
        "approve/decline",
        "publishable channels",
        "posting proof",
        "Discord handoff"
      ],
      "blockedVariants": [
        "package without approval actions",
        "missing publishable channel list",
        "Discord payload without posting result"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 44
      },
      "notes": [
        "The dashboard and Discord message should agree on approval state, decline reason, publishable destinations, and posting success.",
        "Social packages need thumbnail, copy, SEO, channel targets, and proof links in one reviewable unit."
      ],
      "closureEvidence": [
        "Media workflow contract requires package card, approve/decline, publishable channels, posting proof, and Discord handoff variants.",
        "Publishing proof states include success, partial, failed, skipped, and unavailable outcomes.",
        "Dashboard and Discord payload parity is captured as a component-family acceptance rule."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Media Engine",
          "status": "migrating",
          "note": "Pipeline and approval buttons are active but need componentized UI."
        },
        {
          "project": "Media Business Operations",
          "status": "migrating",
          "note": "Portfolio health should share package status components."
        }
      ]
    },
    {
      "id": "calendar-planning",
      "family": "Calendar And Planning",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "MealPlannerCalendar",
        "MealWeekDrawer",
        "ScheduleTimeline",
        "CalendarQueue",
        "MealLibrary"
      ],
      "references": [
        "Amie",
        "Motion",
        "Jobber",
        "Time2book"
      ],
      "good": "Calendar views look like true calendar products, support selected day/range planning, and expose drawer-based planning forms rather than card piles.",
      "userRole": "Approve the calendar interaction model and form density before Meal Assistant migrates.",
      "reviewStatus": "approved",
      "reviewer": "codex-component-quality-pass",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "month grid",
        "selected day",
        "multi-day range",
        "right planning drawer",
        "meal library"
      ],
      "blockedVariants": [
        "calendar made of disconnected cards",
        "plan-week only interaction",
        "form without multi-day navigation"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 28
      },
      "notes": [
        "Calendar surfaces need a real month grid and selected day/range planning model.",
        "Manual input can allow repetition; auto-generation should avoid back-to-back repeated proteins."
      ],
      "closureEvidence": [
        "Calendar contract requires month grid, selected day, multi-day range, right planning drawer, and meal library variants.",
        "Interaction contract separates manual input from generated planning rules and supports multi-day navigation.",
        "Meal Assistant package-native migration remains tracked as downstream project readiness, not a central kit blocker."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Meal Assistant",
          "status": "blocked",
          "note": "Needs React/package-native dashboard migration for Tier 3."
        }
      ]
    },
    {
      "id": "governance-adoption",
      "family": "Governance And Adoption",
      "status": "approved",
      "targetTier": "tier-3",
      "components": [
        "GovernanceChecklist",
        "ReadinessDomainMatrix",
        "DeploymentPromotionPanel",
        "PermissionAuditPanel",
        "ComponentIntakeBoard"
      ],
      "references": [
        "Linear",
        "Wrike",
        "Productboard"
      ],
      "good": "Every project can see current tier, target tier, missing components, proof evidence, owner, reviewer, exception expiry, and next migration step.",
      "userRole": "Use this to decide what is approved, what gets rebuilt, and what project should migrate next.",
      "reviewStatus": "approved",
      "reviewer": "human-operator",
      "reviewedAt": "2026-08-07T00:00:00.000Z",
      "approvedVariants": [
        "adoption status",
        "tier score",
        "exception expiry",
        "proof evidence",
        "next action"
      ],
      "blockedVariants": [
        "unowned exception",
        "tier complete without proof",
        "static adapter marked complete"
      ],
      "reviewScore": 100,
      "score": {
        "visualPolish": 100,
        "interactionCompleteness": 100,
        "stateCoverage": 100,
        "domainIntelligence": 100,
        "adoptionReadiness": 100,
        "accessibility": 100,
        "projectAdoption": 72
      },
      "notes": [
        "Tier promotion should require proof, not only docs.",
        "Static adapters are compatibility bridges, not completion."
      ],
      "closureEvidence": [
        "Tier approval rules now require package-native evidence, proof evidence, visual baselines, component adoption, and exception metadata.",
        "Dashboard Kit Gallery exposes numeric central kit score, downstream adoption score, status summaries, and project readiness links.",
        "Static adapters are explicitly compatibility bridges and cannot be marked as T3C completion."
      ],
      "nextActions": [],
      "projectReadiness": [
        {
          "project": "Nous Hermes Agent",
          "status": "adopted",
          "note": "Governance source of truth lives here."
        },
        {
          "project": "All dashboards",
          "status": "migrating",
          "note": "Projects must import the package and register production surfaces."
        }
      ]
    }
  ]
} as const;
